package com.eforsch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eforsch.entity.UserDetails;
import com.eforsch.entity.UserRole;



@Repository
public interface UserDetailsRepository extends JpaRepository<UserDetails, Long> {
	 
	UserDetails findByUserId(Long id);
	UserDetails findByEmail(String email);
	List<UserDetails> findByUserRole(UserRole role);
	List<UserDetails> findByGroupName(String groupName);
	//List<UserDetails> findByRoleNot(String role);
	
}