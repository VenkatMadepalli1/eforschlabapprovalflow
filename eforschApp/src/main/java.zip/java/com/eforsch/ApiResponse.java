package com.eforsch;

public class ApiResponse {
    private String status;
    private String message;
    private int Code;
    private Errors errors;
    private Data data;
    
	public ApiResponse() {
		super();
	}
	public ApiResponse(String status, String message) {
		super();
		this.status = status;
		this.message = message;
	}
	public Errors getErrors() {
		return errors;
	}
	public void setErrors(Errors errors) {
		this.errors = errors;
	}
	public int getCode() {
		return Code;
	}
	public void setCode(int code) {
		Code = code;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}

    // Getters and Setters
}



