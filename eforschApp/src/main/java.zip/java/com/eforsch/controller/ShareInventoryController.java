package com.eforsch.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eforsch.dto.User;
import com.eforsch.service.SharedInventoryService;
import com.eforsch.util.ErrorResponse;
import com.eforsch.util.ShareInventoryVO;
import com.eforsch.util.SuccessResponse;

@RestController
@RequestMapping("/api/sharedinventory")
public class ShareInventoryController {

    @Autowired
    private SharedInventoryService sharedInventoryService;
    
   @PostMapping("/getSharedProductList")
    public ResponseEntity<?> getSharedProductList(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestBody User user) {

        try {
            Map<String, Object> productData = sharedInventoryService.getProductList(page, size, true, user);

            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("message", "Data fetched successfully");
            response.put("data", Map.of(
                    "columns", List.of(
                            Map.of("key", "productId", "label", "ID", "sortable", true),
                            Map.of("key", "productName", "label", "Product Name", "sortable", true, "filterable", true),
                            Map.of("key", "catalogue", "label", "Catalogue No", "filterable", true),
                            Map.of("key", "companyName", "label", "Company Name", "filterable", true),
                            Map.of("key", "quantity", "label", "Quantity", "sortable", true),
                            Map.of("key", "expiryDate", "label", "Expiry Date", "filterable", true),  
                            Map.of("key", "remark", "label", "Remark", "filterable", true),
                            Map.of("key", "addedBy", "label", "Shared By", "sortable", true)
                            
                    ),
                    "list", productData.get("list"),
                    "pagination", productData.get("pagination")
            ));

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(401).body(new ErrorResponse("error", "Unauthorized. Invalid or missing token.", 401));
        }
    }
    
   
    
    @PostMapping("/shareProduct/{productId}")
    public ResponseEntity<?> shareProduct(@PathVariable Long productId,  @RequestParam String inventoryType, @RequestBody User user) {
        ShareInventoryVO createdProduct = sharedInventoryService.shareProduct(productId, inventoryType, user);
        return ResponseEntity.ok(new SuccessResponse("success", "Product shared successfully", createdProduct));
    }
    
    
}

