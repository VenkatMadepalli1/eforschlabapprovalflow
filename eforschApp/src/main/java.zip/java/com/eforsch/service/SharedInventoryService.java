package com.eforsch.service;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.eforsch.dto.FileDownload;
import com.eforsch.dto.User;
import com.eforsch.entity.FineChemicalInventory;
import com.eforsch.entity.Inventory;
import com.eforsch.repository.FineChemicalInventoryRepository;
import com.eforsch.repository.InventoryRepository;
import com.eforsch.util.InventoryMapper;
import com.eforsch.util.InventoryVO;
import com.eforsch.util.ShareInventoryVO;

@Service
public class SharedInventoryService {

	@Autowired
	private InventoryRepository inventoryRepository;
	
	@Autowired
	private FineChemicalInventoryRepository fineChemicalInventoryRepository;

	
	public ShareInventoryVO shareProduct(Long productId, String inventoryType, User user) {
		
		if (inventoryType == null || inventoryType.isEmpty()) {
			throw new IllegalArgumentException("Inventory type cannot be null or empty");
		}
		if (inventoryType.equalsIgnoreCase("generalInventory")) {
			Inventory inventory = inventoryRepository.findByProductId(productId);
			inventory.setShared(true);
			inventory.setAddedby(user.getName());
			inventory = inventoryRepository.save(inventory);
			return entityToShareInventoryVO(inventory);
			
		}else if(inventoryType.equalsIgnoreCase("fineChemicalInventory")) {
			
			FineChemicalInventory fineChemicalInventory = fineChemicalInventoryRepository.findByProductId(productId);
			if (fineChemicalInventory == null) {
				throw new RuntimeException("Fine Chemical Product not found");
			}
			
			fineChemicalInventory.setShared(true);
			FineChemicalInventory inventory = fineChemicalInventoryRepository.save(fineChemicalInventory);
			return entityToShareInventoryVO(inventory);
		}
		
		return null;
	}

	/**
	 * @param inv
	 * @return
	 */
	public static ShareInventoryVO entityToShareInventoryVO(Inventory inv) {
        if (inv == null) return null;

        ShareInventoryVO vo = new ShareInventoryVO();

        vo.setProductId(inv.getProductId());
        vo.setProductName(inv.getProductname());
        vo.setCatalogue(inv.getCatalogue());
        vo.setCompanyName(inv.getCompanyname());

        // Quantity: if your entity has Integer, keep it, else convert String → Integer
        if (inv.getQuantity() != null) {
            try {
                vo.setQuantity(Integer.valueOf(inv.getQuantity().toString()));
            } catch (Exception e) {
                vo.setQuantity(null);
            }
        }

        vo.setGroupName(inv.getGroupName());
        vo.setCompanyInternalNo(inv.getCompanyinternalno());
        vo.setSapMaterialNo(inv.getSapmaterialno());
        vo.setWeightVolSubQty(inv.getWeightvolsubqty());
        vo.setBudgetNo(inv.getBudgetno());
        vo.setConcentration(inv.getConcentration());

        vo.setRemarks(inv.getRemarks());
        vo.setOrderDate(inv.getOrderdate());
        vo.setExpiryDate(inv.getExpirydate());

        vo.setAddedBy(inv.getAddedby());
        vo.setShared(inv.isShared());
        vo.setInventoryType("generalInventory");

        return vo;
    }
	
	public static ShareInventoryVO entityToShareInventoryVO(FineChemicalInventory inv) {
        if (inv == null) return null;

        ShareInventoryVO vo = new ShareInventoryVO();

        vo.setProductId(inv.getProductId());
        vo.setProductName(inv.getProductname());
        vo.setCatalogue(inv.getCatalogue());
        vo.setCompanyName(inv.getCompanyname());

        // Quantity: if your entity has Integer, keep it, else convert String → Integer
        if (inv.getQuantity() != null) {
            try {
                vo.setQuantity(Integer.valueOf(inv.getQuantity().toString()));
            } catch (Exception e) {
                vo.setQuantity(null);
            }
        }

        vo.setGroupName(inv.getGroupName());
        vo.setBudgetNo(inv.getBudgetno());
        vo.setConcentration(inv.getConcentration());
        vo.setOrderDate(inv.getOrderdate());
               vo.setShared(inv.isShared());
               //vo.setaddedBy(inv.getAddedby());
        vo.setInventoryType("fineChemicalInventory");

        return vo;
    }
	
	
	public Map<String, Object> getProductList(int page, int size, boolean shared, User user) {
		Page<Inventory> paginatedResult = null;
		Page<FineChemicalInventory> paginatedFCResult = null;
		List<ShareInventoryVO> inventoryVOList = new ArrayList<>();

		
			paginatedResult = inventoryRepository.findByShared(true, PageRequest.of(page - 1, size));
			
			if( (paginatedResult == null || paginatedResult.getTotalElements() == 0)) {
                throw new RuntimeException("No shared products found");
            }
			
			for (Inventory inventory : paginatedResult.getContent()) {
				ShareInventoryVO inventoryVO = entityToShareInventoryVO(inventory);
				inventoryVOList.add(inventoryVO);
			}
			
			paginatedFCResult = fineChemicalInventoryRepository.findByShared(true, PageRequest.of(page - 1, size));
			
			if( (paginatedFCResult != null && paginatedFCResult.getTotalElements() > 0)) {
				for (FineChemicalInventory inventory : paginatedFCResult.getContent()) {
					ShareInventoryVO inventoryVO = entityToShareInventoryVO(inventory);
					inventoryVOList.add(inventoryVO);
				}   
            }
			
			
		int currentPageCount = 	paginatedResult.getNumber() + paginatedFCResult.getNumber() + 1;
		int pageSize = paginatedResult.getSize() + paginatedFCResult.getSize();
		int totalRecords = (int) (paginatedResult.getTotalElements() + paginatedFCResult.getTotalElements());
		int totalPages = paginatedResult.getTotalPages() + paginatedFCResult.getTotalPages();
			
			
		Map<String, Object> response = new HashMap<>();
		response.put("list", inventoryVOList);
		response.put("pagination",
				Map.of("currentPage", currentPageCount, "pageSize", pageSize,
						"totalRecords", totalRecords, "totalPages",
						totalPages));

		return response;
	}
	
}
