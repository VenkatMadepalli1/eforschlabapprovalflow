package com.eforsch.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.eforsch.dto.NotificationVO;
import com.eforsch.entity.NotificationEntity;
import com.eforsch.entity.Order;
import com.eforsch.repository.NotificationRepository;
import com.eforsch.repository.OrderRepository;
import com.eforsch.util.OrderConverter;
import com.eforsch.util.OrderVO;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;
    
	@Autowired
	private NotificationService notificationService;
	
	@Autowired
	private NotificationRepository notificationRepository;


    public Map<String, Object> getOrdersList(int page, int size) {
        Page<Order> paginatedResult = orderRepository.findAll(PageRequest.of(page - 1, size));
        
        List<OrderVO> orderVOList = new ArrayList<>();
        for (Order order : paginatedResult.getContent()) {
            OrderVO orderVO = OrderConverter.fromEntityToVO(order);
            orderVOList.add(orderVO);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("list", orderVOList);
        response.put("pagination", Map.of(
                "currentPage", paginatedResult.getNumber() + 1,
                "pageSize", paginatedResult.getSize(),
                "totalRecords", paginatedResult.getTotalElements(),
                "totalPages", paginatedResult.getTotalPages()
        ));

        return response;
    }
    
    public Map<String, Object> getOrdersListByGroupName(int page, int size, String groupName, String role) {
    	
    	Page<Order> paginatedResult = null;
		if (role.equals("podept")) {
			paginatedResult = orderRepository.findByLabApproved(true, PageRequest.of(page - 1, size));
		}else if(role.equalsIgnoreCase("labMgmt")) {
			paginatedResult = orderRepository.findByAdminApproved(true, PageRequest.of(page - 1, size));
		}else if(role.equalsIgnoreCase("admin")) {
			paginatedResult = orderRepository.findAll(PageRequest.of(page - 1, size));
		}else if(groupName != null && !groupName.isEmpty()) {
			paginatedResult = orderRepository.findByGroupName(groupName, PageRequest.of(page - 1, size));
		}else {
			paginatedResult = orderRepository.findAll(PageRequest.of(page - 1, size));
		}
		
		List<OrderVO> orderVOList = new ArrayList<>();
        for (Order order : paginatedResult.getContent()) {
            OrderVO orderVO = OrderConverter.fromEntityToVO(order);
            orderVOList.add(orderVO);
        }
  
		Map<String, Object> response = new HashMap<>();
        response.put("list", orderVOList);
        response.put("pagination", Map.of(
                "currentPage", paginatedResult.getNumber() + 1,
                "pageSize", paginatedResult.getSize(),
                "totalRecords", paginatedResult.getTotalElements(),
                "totalPages", paginatedResult.getTotalPages()
        ));

        return response;
    }
    
    // write a method same as getOrdersListByStatus for status is ordered
	public Map<String, Object> getOrdersListByStatus(int page, int size, String status) {
		Page<Order> paginatedResult = orderRepository.findByStatus(status, PageRequest.of(page - 1, size));

		 List<OrderVO> orderVOList = new ArrayList<>();
	        for (Order order : paginatedResult.getContent()) {
	            OrderVO orderVO = OrderConverter.fromEntityToVO(order);
	            orderVOList.add(orderVO);
	        }
		
		
		Map<String, Object> response = new HashMap<>();
		response.put("list", orderVOList);
		response.put("pagination",
				Map.of("currentPage", paginatedResult.getNumber() + 1, "pageSize", paginatedResult.getSize(),
						"totalRecords", paginatedResult.getTotalElements(), "totalPages",
						paginatedResult.getTotalPages()));

		return response;
	}
    
    
    public Map<String, Object> getOrderList(int page, int size) {
        Page<Order> paginatedResult = orderRepository.findAll(PageRequest.of(page - 1, size));

        List<OrderVO> orderVOList = new ArrayList<>();
        for (Order order : paginatedResult.getContent()) {
            OrderVO orderVO = OrderConverter.fromEntityToVO(order);
            orderVOList.add(orderVO);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("list", orderVOList);
        response.put("pagination", Map.of(
                "currentPage", paginatedResult.getNumber() + 1,
                "pageSize", paginatedResult.getSize(),
                "totalRecords", paginatedResult.getTotalElements(),
                "totalPages", paginatedResult.getTotalPages()
        ));

        return response;
    }
    
 // Get order by ID
    public Order getOrderById(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + orderId));
    }

    public OrderVO addOrder(OrderVO orderVO) {
        Order newOrder = OrderConverter.fromVOToEntity(orderVO, new Order());
        newOrder = orderRepository.save(newOrder);
        
     // Create a notification after successfully creating the order
        NotificationVO notificationVO = new NotificationVO();
        notificationVO.setTitle("Pending Approval Request");
        notificationVO.setMessage("Order #"+newOrder.getOrderId() + " requires your approval.");
        notificationVO.setType("approval_pending");
        notificationVO.setEntityId(newOrder.getOrderId());
        notificationVO.setEntityType("Order");
        notificationVO.setRole(orderVO.getRole()); // Set the appropriate role
        notificationVO.setGroupName(orderVO.getGroupName()); // Set the appropriate group name
        notificationVO.setCreatedAt(System.currentTimeMillis());
        notificationVO.setRead(false);
        notificationService.createNotification(notificationVO);
        
        return OrderConverter.fromEntityToVO(newOrder);
    }
    
    public OrderVO approveAdmin(Long orderId) {
    	Optional<Order> orderOptional = orderRepository.findById(orderId);
    	
		if (orderOptional.isPresent()) {
			Order existingOrder = orderOptional.get();
			existingOrder.setAdminApproved(true);
			existingOrder.setAdminApprovalStatusDate(new java.util.Date());
			existingOrder = orderRepository.save(existingOrder);
			
			Optional<NotificationEntity> notificationOptional = notificationRepository.findByEntityId(orderId);

			if (notificationOptional.isPresent()) {
			    NotificationEntity notificationEntity = notificationOptional.get();
			    notificationEntity.setMessage("Order #" + orderId + " has been approved by Group Leader. Now requires your approval.");
			    notificationEntity.setTitle("Pending Lab Approval Request");
			    notificationEntity.setType("approval_pending");
			    notificationEntity.setRole("labMgmt"); // Update role to labMgmt
			    notificationEntity.setRead(false); // Example of updating the read status
			    notificationEntity.setUpdatedAt(new java.util.Date()); // Assuming you have an updatedAt field
			    notificationRepository.save(notificationEntity);
			} else {
			    throw new RuntimeException("Notification not found for Order ID: " + orderId);
			}
			return OrderConverter.fromEntityToVO(existingOrder);
		} else {
			throw new RuntimeException("Order not found");
		}
    }
    
    public OrderVO rejectAdmin(Long orderId) {
    	Optional<Order> orderOptional = orderRepository.findById(orderId);
    	
		if (orderOptional.isPresent()) {
			Order existingOrder = orderOptional.get();
			existingOrder.setAdminApproved(false);
			existingOrder = orderRepository.save(existingOrder);
			
			Optional<NotificationEntity> notificationOptional = notificationRepository.findByEntityId(orderId);

			if (notificationOptional.isPresent()) {
			    NotificationEntity notificationEntity = notificationOptional.get();
			    notificationEntity.setMessage("Order #" + orderId + " has been rejected by Group Leader.");
			    notificationEntity.setTitle("Order Rejected by Group Leader");
			    notificationEntity.setType("rejected");
			    notificationEntity.setRole("groupleader"); // Update role to labMgmt
			    notificationEntity.setRead(false); // Example of updating the read status
			    notificationEntity.setUpdatedAt(new java.util.Date()); // Assuming you have an updatedAt field
			    notificationRepository.save(notificationEntity);
			} else {
			    throw new RuntimeException("Notification not found for Order ID: " + orderId);
			}
			
			
			
			return OrderConverter.fromEntityToVO(existingOrder);
		} else {
			throw new RuntimeException("Order not found");
		}
    }
    
    public OrderVO labApprove(Long orderId) {
    	Optional<Order> orderOptional = orderRepository.findById(orderId);
    	
		if (orderOptional.isPresent()) {
			Order existingOrder = orderOptional.get();
			existingOrder.setLabApproved(true);
			existingOrder.setLabApprovalStatusDate(new java.util.Date());
			existingOrder = orderRepository.save(existingOrder);
			
			Optional<NotificationEntity> notificationOptional = notificationRepository.findByEntityId(orderId);

			if (notificationOptional.isPresent()) {
			    NotificationEntity notificationEntity = notificationOptional.get();
			    notificationEntity.setMessage("Order #" + orderId + " has been approved by Lab Management.");
			    notificationEntity.setTitle("Lab Approval Completed");
			    notificationEntity.setType("approved");
			    notificationEntity.setRole("podept"); // Update role to labMgmt
			    notificationEntity.setRead(false); // Example of updating the read status
			    notificationEntity.setUpdatedAt(new java.util.Date()); // Assuming you have an updatedAt field
			    notificationRepository.save(notificationEntity);
			} else {
			    throw new RuntimeException("Notification not found for Order ID: " + orderId);
			}
			return OrderConverter.fromEntityToVO(existingOrder);
		} else {
			throw new RuntimeException("Order not found");
		}
    }
    
    public OrderVO labReject(Long orderId) {
    	Optional<Order> orderOptional = orderRepository.findById(orderId);
    	
		if (orderOptional.isPresent()) {
			Order existingOrder = orderOptional.get();
			existingOrder.setLabApproved(false);
			existingOrder = orderRepository.save(existingOrder);
			
			
			Optional<NotificationEntity> notificationOptional = notificationRepository.findByEntityId(orderId);

			if (notificationOptional.isPresent()) {
			    NotificationEntity notificationEntity = notificationOptional.get();
			    notificationEntity.setMessage("Order #" + orderId + " has been rejected by Lab Management.");
			    notificationEntity.setTitle("Lab Rejected");
			    notificationEntity.setType("rejected");
			    notificationEntity.setRole("groupleader"); // Update role to labMgmt
			    notificationEntity.setRead(false); // Example of updating the read status
			    notificationEntity.setUpdatedAt(new java.util.Date()); // Assuming you have an updatedAt field
			    notificationRepository.save(notificationEntity);
			} else {
			    throw new RuntimeException("Notification not found for Order ID: " + orderId);
			}
			return OrderConverter.fromEntityToVO(existingOrder);
		} else {
			throw new RuntimeException("Order not found");
		}
    }
    
    

    public OrderVO modifyOrder(OrderVO updatedOrderVO) {
        Optional<Order> orderOptional = orderRepository.findById(updatedOrderVO.getOrderId());

        if (orderOptional.isPresent()) {
            Order existingOrder = orderOptional.get();
            
            Order updatedOrder = OrderConverter.fromVOToEntity(updatedOrderVO, new Order());
            
            // Retain createdAt from the existing order
            updatedOrder.setCreatedAt(existingOrder.getCreatedAt());

            // Save updated entity
            updatedOrder = orderRepository.save(updatedOrder);
            
            return OrderConverter.fromEntityToVO(updatedOrder);
        } else {
            throw new RuntimeException("Order not found");
        }
    }

    public void deleteOrder(Long orderId) {
        orderRepository.deleteById(orderId);
    }
}

